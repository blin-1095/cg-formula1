# Computergrafik Programmentwurf

# Run the Application

There is a precompiled version of the application. Find the right binary in `./bin` and execute it from
the project root. The application should be accessible under `https://locahost:8081`

## Local Setup

First install all required dependencies using yarn

```bash
$ yarn
```

Now the local development server can be started

```bash
$ yarn dev
```

The web ui can now be accessed under [localhost:8000/web](http://localhost:8000/web)
